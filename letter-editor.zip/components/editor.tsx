"use client"

import { useEffect, useState } from "react"
import { EditorContent, useEditor } from "@tiptap/react"
import StarterKit from "@tiptap/starter-kit"
import Underline from "@tiptap/extension-underline"
import TextAlign from "@tiptap/extension-text-align"
import { Toggle } from "@/components/ui/toggle"
import {
  Bold,
  Italic,
  UnderlineIcon,
  AlignLeft,
  AlignCenter,
  AlignRight,
  List,
  ListOrdered,
  Heading1,
  Heading2,
} from "lucide-react"

interface EditorProps {
  value: string
  onChange: (value: string) => void
}

export default function Editor({ value, onChange }: EditorProps) {
  const [isMounted, setIsMounted] = useState(false)

  const editor = useEditor({
    extensions: [
      StarterKit,
      Underline,
      TextAlign.configure({
        types: ["heading", "paragraph"],
        alignments: ["left", "center", "right"],
      }),
    ],
    content: value,
    onUpdate: ({ editor }) => {
      onChange(editor.getHTML())
    },
  })

  useEffect(() => {
    setIsMounted(true)
  }, [])

  useEffect(() => {
    if (editor && value !== editor.getHTML()) {
      editor.commands.setContent(value)
    }
  }, [editor, value])

  if (!isMounted) {
    return null
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap gap-1 border-b pb-2">
        <Toggle
          pressed={editor?.isActive("bold") || false}
          onPressedChange={() => editor?.chain().focus().toggleBold().run()}
          aria-label="Bold"
          size="sm"
        >
          <Bold className="h-4 w-4" />
        </Toggle>
        <Toggle
          pressed={editor?.isActive("italic") || false}
          onPressedChange={() => editor?.chain().focus().toggleItalic().run()}
          aria-label="Italic"
          size="sm"
        >
          <Italic className="h-4 w-4" />
        </Toggle>
        <Toggle
          pressed={editor?.isActive("underline") || false}
          onPressedChange={() => editor?.chain().focus().toggleUnderline().run()}
          aria-label="Underline"
          size="sm"
        >
          <UnderlineIcon className="h-4 w-4" />
        </Toggle>
        <div className="w-px h-6 bg-border mx-1" />
        <Toggle
          pressed={editor?.isActive("heading", { level: 1 }) || false}
          onPressedChange={() => editor?.chain().focus().toggleHeading({ level: 1 }).run()}
          aria-label="Heading 1"
          size="sm"
        >
          <Heading1 className="h-4 w-4" />
        </Toggle>
        <Toggle
          pressed={editor?.isActive("heading", { level: 2 }) || false}
          onPressedChange={() => editor?.chain().focus().toggleHeading({ level: 2 }).run()}
          aria-label="Heading 2"
          size="sm"
        >
          <Heading2 className="h-4 w-4" />
        </Toggle>
        <div className="w-px h-6 bg-border mx-1" />
        <Toggle
          pressed={editor?.isActive("bulletList") || false}
          onPressedChange={() => editor?.chain().focus().toggleBulletList().run()}
          aria-label="Bullet List"
          size="sm"
        >
          <List className="h-4 w-4" />
        </Toggle>
        <Toggle
          pressed={editor?.isActive("orderedList") || false}
          onPressedChange={() => editor?.chain().focus().toggleOrderedList().run()}
          aria-label="Ordered List"
          size="sm"
        >
          <ListOrdered className="h-4 w-4" />
        </Toggle>
        <div className="w-px h-6 bg-border mx-1" />
        <Toggle
          pressed={editor?.isActive({ textAlign: "left" }) || false}
          onPressedChange={() => editor?.chain().focus().setTextAlign("left").run()}
          aria-label="Align Left"
          size="sm"
        >
          <AlignLeft className="h-4 w-4" />
        </Toggle>
        <Toggle
          pressed={editor?.isActive({ textAlign: "center" }) || false}
          onPressedChange={() => editor?.chain().focus().setTextAlign("center").run()}
          aria-label="Align Center"
          size="sm"
        >
          <AlignCenter className="h-4 w-4" />
        </Toggle>
        <Toggle
          pressed={editor?.isActive({ textAlign: "right" }) || false}
          onPressedChange={() => editor?.chain().focus().setTextAlign("right").run()}
          aria-label="Align Right"
          size="sm"
        >
          <AlignRight className="h-4 w-4" />
        </Toggle>
      </div>
      <EditorContent editor={editor} className="prose dark:prose-invert max-w-none min-h-[60vh] focus:outline-none" />
    </div>
  )
}

