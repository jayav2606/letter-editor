"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useSession, signIn, signOut } from "next-auth/react"
import { ModeToggle } from "./mode-toggle"

export default function Header() {
  const { data: session, status } = useSession()
  const isLoading = status === "loading"

  return (
    <header className="border-b">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="font-bold text-xl">
          Letter Editor
        </Link>
        <div className="flex items-center gap-4">
          <ModeToggle />
          {isLoading ? (
            <Button variant="outline" disabled>
              Loading...
            </Button>
          ) : session ? (
            <div className="flex items-center gap-4">
              <span className="text-sm hidden md:inline-block">{session.user?.name}</span>
              <Button variant="outline" onClick={() => signOut()}>
                Sign Out
              </Button>
            </div>
          ) : (
            <Button onClick={() => signIn("google")}>Sign In</Button>
          )}
        </div>
      </div>
    </header>
  )
}

