"use client"

import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Loader2, Save } from "lucide-react"
import dynamic from "next/dynamic"
import { useToast } from "@/hooks/use-toast"

// Import the editor dynamically to avoid SSR issues
const Editor = dynamic(() => import("@/components/editor"), {
  ssr: false,
  loading: () => <div className="h-64 flex items-center justify-center">Loading editor...</div>,
})

export default function EditorPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const { toast } = useToast()
  const [title, setTitle] = useState("Untitled Letter")
  const [content, setContent] = useState("")
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/auth/signin")
    }
  }, [status, router])

  const handleSave = async () => {
    if (!content) {
      toast({
        title: "Cannot save empty letter",
        description: "Please add some content to your letter before saving.",
        variant: "destructive",
      })
      return
    }

    setSaving(true)
    try {
      const response = await fetch("/api/letters", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title,
          content,
        }),
      })

      if (response.ok) {
        toast({
          title: "Letter saved",
          description: "Your letter has been saved to Google Drive.",
        })
        router.push("/dashboard")
      } else {
        const error = await response.json()
        throw new Error(error.message || "Failed to save letter")
      }
    } catch (error: any) {
      toast({
        title: "Error saving letter",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  if (status === "loading") {
    return (
      <div className="container mx-auto px-4 py-8 flex items-center justify-center min-h-[calc(100vh-80px)]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="text-2xl font-bold border-none shadow-none focus-visible:ring-0 p-0 max-w-md"
        />
        <Button onClick={handleSave} disabled={saving}>
          {saving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              Save to Drive
            </>
          )}
        </Button>
      </div>

      <Card className="p-4 min-h-[70vh]">
        <Editor value={content} onChange={setContent} />
      </Card>
    </div>
  )
}

