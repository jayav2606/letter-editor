import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-3xl mx-auto text-center">
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl mb-6">Create and Save Letters to Google Drive</h1>
        <p className="text-lg text-muted-foreground mb-8">
          A simple yet powerful letter editor that lets you create, edit, and save your letters directly to Google
          Drive.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild size="lg">
            <Link href="/editor">Create New Letter</Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link href="/dashboard">View My Letters</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}

