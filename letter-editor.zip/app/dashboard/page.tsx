"use client"

import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import Link from "next/link"
import { FileText, Plus, ExternalLink, Trash2 } from "lucide-react"

interface Letter {
  id: string
  name: string
  createdTime: string
  webViewLink: string
}

export default function Dashboard() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [letters, setLetters] = useState<Letter[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/auth/signin")
    }

    if (status === "authenticated") {
      fetchLetters()
    }
  }, [status, router])

  const fetchLetters = async () => {
    try {
      const response = await fetch("/api/letters")
      if (response.ok) {
        const data = await response.json()
        setLetters(data)
      }
    } catch (error) {
      console.error("Error fetching letters:", error)
    } finally {
      setLoading(false)
    }
  }

  const deleteDocument = async (id: string) => {
    try {
      const response = await fetch(`/api/letters/${id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        setLetters(letters.filter((letter) => letter.id !== id))
      }
    } catch (error) {
      console.error("Error deleting document:", error)
    }
  }

  if (status === "loading" || loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">My Letters</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-5 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-2/3" />
              </CardContent>
              <CardFooter>
                <Skeleton className="h-10 w-full" />
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">My Letters</h1>
        <Button asChild>
          <Link href="/editor">
            <Plus className="mr-2 h-4 w-4" /> New Letter
          </Link>
        </Button>
      </div>

      {letters.length === 0 ? (
        <div className="text-center py-12">
          <FileText className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <h2 className="text-xl font-semibold mb-2">No letters yet</h2>
          <p className="text-muted-foreground mb-6">Create your first letter to get started</p>
          <Button asChild>
            <Link href="/editor">
              <Plus className="mr-2 h-4 w-4" /> Create Letter
            </Link>
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {letters.map((letter) => (
            <Card key={letter.id}>
              <CardHeader>
                <CardTitle>{letter.name}</CardTitle>
                <CardDescription>Created on {new Date(letter.createdTime).toLocaleDateString()}</CardDescription>
              </CardHeader>
              <CardFooter className="flex justify-between">
                <Button variant="outline" asChild>
                  <Link href={`/editor/${letter.id}`}>Edit</Link>
                </Button>
                <div className="flex gap-2">
                  <Button variant="outline" size="icon" asChild>
                    <a href={letter.webViewLink} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  </Button>
                  <Button variant="outline" size="icon" onClick={() => deleteDocument(letter.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

