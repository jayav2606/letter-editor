import { getServerSession } from "next-auth/next"
import { authOptions } from "../../auth/[...nextauth]/route"
import { google } from "googleapis"
import { type NextRequest, NextResponse } from "next/server"

// Helper function to get Google Drive client
async function getDriveClient(session: any) {
  const oauth2Client = new google.auth.OAuth2(process.env.GOOGLE_CLIENT_ID, process.env.GOOGLE_CLIENT_SECRET)

  oauth2Client.setCredentials({
    access_token: session.token.accessToken,
    refresh_token: session.token.refreshToken,
  })

  return google.drive({ version: "v3", auth: oauth2Client })
}

// GET handler to fetch a specific letter
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const drive = await getDriveClient(session)
    const fileId = params.id

    // Get file metadata
    const fileResponse = await drive.files.get({
      fileId,
      fields: "id,name,webViewLink",
    })

    // Get file content
    const contentResponse = await drive.files.export({
      fileId,
      mimeType: "text/html",
    })

    return NextResponse.json({
      id: fileResponse.data.id,
      name: fileResponse.data.name,
      webViewLink: fileResponse.data.webViewLink,
      content: contentResponse.data,
    })
  } catch (error: any) {
    console.error("Error fetching letter:", error)
    return NextResponse.json({ error: error.message || "Failed to fetch letter" }, { status: 500 })
  }
}

// PUT handler to update a letter
export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { title, content } = await request.json()
    const fileId = params.id

    if (!title || !content) {
      return NextResponse.json({ error: "Title and content are required" }, { status: 400 })
    }

    const drive = await getDriveClient(session)

    // Update file name if changed
    await drive.files.update({
      fileId,
      resource: {
        name: title,
      },
    })

    // Update file content
    await drive.files.update({
      fileId,
      media: {
        mimeType: "text/html",
        body: content,
      },
    })

    // Get updated file metadata
    const fileResponse = await drive.files.get({
      fileId,
      fields: "id,name,webViewLink",
    })

    return NextResponse.json(fileResponse.data)
  } catch (error: any) {
    console.error("Error updating letter:", error)
    return NextResponse.json({ error: error.message || "Failed to update letter" }, { status: 500 })
  }
}

// DELETE handler to delete a letter
export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const drive = await getDriveClient(session)
    const fileId = params.id

    await drive.files.delete({
      fileId,
    })

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("Error deleting letter:", error)
    return NextResponse.json({ error: error.message || "Failed to delete letter" }, { status: 500 })
  }
}

