import { getServerSession } from "next-auth/next"
import { authOptions } from "../auth/[...nextauth]/route"
import { google } from "googleapis"
import { type NextRequest, NextResponse } from "next/server"

// Helper function to get Google Drive client
async function getDriveClient(session: any) {
  const oauth2Client = new google.auth.OAuth2(process.env.GOOGLE_CLIENT_ID, process.env.GOOGLE_CLIENT_SECRET)

  oauth2Client.setCredentials({
    access_token: session.token.accessToken,
    refresh_token: session.token.refreshToken,
  })

  return google.drive({ version: "v3", auth: oauth2Client })
}

// Create or get the "Letters" folder
async function getOrCreateLettersFolder(drive: any) {
  // Check if "Letters" folder exists
  const response = await drive.files.list({
    q: "name='Letters' and mimeType='application/vnd.google-apps.folder' and trashed=false",
    fields: "files(id, name)",
  })

  if (response.data.files && response.data.files.length > 0) {
    return response.data.files[0].id
  }

  // Create "Letters" folder if it doesn't exist
  const folderMetadata = {
    name: "Letters",
    mimeType: "application/vnd.google-apps.folder",
  }

  const folder = await drive.files.create({
    resource: folderMetadata,
    fields: "id",
  })

  return folder.data.id
}

// GET handler to list all letters
export async function GET() {
  const session = await getServerSession(authOptions)

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const drive = await getDriveClient(session)
    const folderId = await getOrCreateLettersFolder(drive)

    const response = await drive.files.list({
      q: `'${folderId}' in parents and trashed=false`,
      fields: "files(id, name, createdTime, webViewLink)",
    })

    return NextResponse.json(response.data.files || [])
  } catch (error: any) {
    console.error("Error fetching letters:", error)
    return NextResponse.json({ error: error.message || "Failed to fetch letters" }, { status: 500 })
  }
}

// POST handler to create a new letter
export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { title, content } = await request.json()

    if (!title || !content) {
      return NextResponse.json({ error: "Title and content are required" }, { status: 400 })
    }

    const drive = await getDriveClient(session)
    const folderId = await getOrCreateLettersFolder(drive)

    // Create a Google Doc
    const fileMetadata = {
      name: title,
      mimeType: "application/vnd.google-apps.document",
      parents: [folderId],
    }

    // Upload the document
    const file = await drive.files.create({
      resource: fileMetadata,
      media: {
        mimeType: "text/html",
        body: content,
      },
      fields: "id,name,webViewLink",
    })

    return NextResponse.json(file.data)
  } catch (error: any) {
    console.error("Error creating letter:", error)
    return NextResponse.json({ error: error.message || "Failed to create letter" }, { status: 500 })
  }
}

